var     express = require('express'),
        app = express(),
        bodyParser = require('body-parser'),
        connection = require('./connection'),
        credMiddleWare = require('./login/router');
        registerMiddleWare = require('./register/router');
app.use(bodyParser.json());
app.use('/',[credMiddleWare,registerMiddleWare]);
module.exports = app;

