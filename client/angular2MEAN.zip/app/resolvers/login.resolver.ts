import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { LoginService } from '../providers/login.service';

@Injectable()
export class UserDataResolver implements Resolve<any> {
  constructor(
    private loginService: LoginService
  ) {}

  resolve(route: ActivatedRouteSnapshot): Observable<any> {
    return this.loginService.checkAuthentication(route.params.id);
  }
}
