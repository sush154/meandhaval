"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require('./providers/user.service');
var DashboardComponent = (function () {
    function DashboardComponent(userService, route) {
        this.userService = userService;
        this.route = route;
    }
    DashboardComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) { _this.userId = params['id']; });
        this.userService.getUser(this.userId).then(function (response) { _this.userData = response.user; console.log(_this.userData); });
    };
    DashboardComponent = __decorate([
        core_1.Component({
            selector: 'my-dashboard',
            template: "<div class=\"container\">\n              \t<div class=\"row\">\n              \t\t<div style=\"width: 100%\">\n\n                          <div class=\"card hovercard\">\n                              <div class=\"cardheader\">\n\n                              </div>\n                              <div class=\"avatar\">\n                                  <img alt=\"\" src=\"http://lorempixel.com/100/100/people/9/\">\n                              </div>\n                              <div class=\"info\">\n                                  <div class=\"title\">\n                                      <a target=\"_blank\" href=\"http://scripteden.com/\">{{userData?.firstName}} {{userData?.lastName}}</a>\n                                  </div>\n                              </div>\n\n                          </div>\n\n                  </div>\n\n              \t</div>\n              </div>",
            providers: [user_service_1.UserService],
            styleUrls: ['node_modules/font-awesome/css/font-awesome.css', 'app/style/dashboard.css']
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService, router_1.ActivatedRoute])
    ], DashboardComponent);
    return DashboardComponent;
}());
exports.DashboardComponent = DashboardComponent;
//# sourceMappingURL=dashboard.component.js.map