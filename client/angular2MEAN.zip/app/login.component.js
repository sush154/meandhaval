"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var login_service_1 = require('./providers/login.service');
var router_1 = require('@angular/router');
var LoginComponent = (function () {
    function LoginComponent(router, loginService) {
        this.router = router;
        this.loginService = loginService;
        this.credData = {};
    }
    LoginComponent.prototype.login = function (credData) {
        var _this = this;
        console.log(credData);
        this.loginService.checkAuthentication(credData).then(function (response) {
            console.log(response);
            _this.router.navigate(['/dashboard', response.user._id]);
        });
    };
    LoginComponent = __decorate([
        core_1.Component({
            selector: 'login',
            template: "<div class=\"text-center content-center\" ><div class=\"login-form-1\">\n              \t\t<form id=\"login-form\" class=\"text-left\">\n              \t\t\t<div class=\"login-form-main-message\"></div>\n              \t\t\t<div class=\"main-login-form\">\n              \t\t\t\t<div class=\"login-group\">\n              \t\t\t\t\t<div class=\"form-group\">\n              \t\t\t\t\t\t<label for=\"lg_username\" class=\"sr-only\">Username</label>\n              \t\t\t\t\t\t<input [(ngModel)]=\"credData.email\" type=\"text\" class=\"form-control\" id=\"lg_username\" name=\"lg_username\" placeholder=\"username\">\n              \t\t\t\t\t</div>\n              \t\t\t\t\t<div class=\"form-group\">\n              \t\t\t\t\t\t<label for=\"lg_password\" class=\"sr-only\">Password</label>\n              \t\t\t\t\t\t<input [(ngModel)]=\"credData.password\" type=\"password\" class=\"form-control\" id=\"lg_password\" name=\"lg_password\" placeholder=\"password\">\n              \t\t\t\t\t</div>\n              \t\t\t\t\t<div class=\"form-group login-group-checkbox\">\n              \t\t\t\t\t\t<input type=\"checkbox\" id=\"lg_remember\" name=\"lg_remember\">\n              \t\t\t\t\t\t<label for=\"lg_remember\">remember</label>\n              \t\t\t\t\t</div>\n              \t\t\t\t</div>\n              \t\t\t\t<button type=\"submit\" (click)=\"login(credData)\" class=\"login-button\"><i class=\"fa fa-chevron-right\"></i></button>\n              \t\t\t</div>\n              \t\t\t<div class=\"etc-login-form\">\n              \t\t\t\t<p>forgot your password? <a href=\"#\">click here</a></p>\n              \t\t\t\t<p>new user? <a href=\"#\">create new account</a></p>\n              \t\t\t</div>\n              \t\t</form>\n              \t</div></div> ",
            styleUrls: ['node_modules/font-awesome/css/font-awesome.css', 'app/style/login.css'],
            providers: [login_service_1.LoginService]
        }), 
        __metadata('design:paramtypes', [router_1.Router, login_service_1.LoginService])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map